################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../conf/FreeRTOSConfig.c 

OBJS += \
./conf/FreeRTOSConfig.o 

C_DEPS += \
./conf/FreeRTOSConfig.d 


# Each subdirectory must supply rules for building sources it contributes
conf/%.o conf/%.su conf/%.cyclo: ../conf/%.c conf/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F334x8 -c -I../Core/Inc -I../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F3xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F3xx/Include -I../Drivers/CMSIS/Include -I../FreeRTOS/include -I../FreeRTOS/portable/GCC/ARM_CM4F -I../conf -I../Task/HAL -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/Task" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-conf

clean-conf:
	-$(RM) ./conf/FreeRTOSConfig.cyclo ./conf/FreeRTOSConfig.d ./conf/FreeRTOSConfig.o ./conf/FreeRTOSConfig.su

.PHONY: clean-conf

