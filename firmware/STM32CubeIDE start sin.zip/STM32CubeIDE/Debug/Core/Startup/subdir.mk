################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../Core/Startup/startup_stm32f334c8tx.s 

OBJS += \
./Core/Startup/startup_stm32f334c8tx.o 

S_DEPS += \
./Core/Startup/startup_stm32f334c8tx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Startup/%.o: ../Core/Startup/%.s Core/Startup/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/FreeRTOS/include" -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/FreeRTOS/portable/GCC/ARM_CM4F" -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/conf" -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/Task/HAL" -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/Task" -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-Core-2f-Startup

clean-Core-2f-Startup:
	-$(RM) ./Core/Startup/startup_stm32f334c8tx.d ./Core/Startup/startup_stm32f334c8tx.o

.PHONY: clean-Core-2f-Startup

