################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Task/HAL/adc.c \
../Task/HAL/hrtim.c 

OBJS += \
./Task/HAL/adc.o \
./Task/HAL/hrtim.o 

C_DEPS += \
./Task/HAL/adc.d \
./Task/HAL/hrtim.d 


# Each subdirectory must supply rules for building sources it contributes
Task/HAL/%.o Task/HAL/%.su Task/HAL/%.cyclo: ../Task/HAL/%.c Task/HAL/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F334x8 -c -I../Core/Inc -I../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F3xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F3xx/Include -I../Drivers/CMSIS/Include -I../FreeRTOS/include -I../FreeRTOS/portable/GCC/ARM_CM4F -I../conf -I../Task/HAL -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Task-2f-HAL

clean-Task-2f-HAL:
	-$(RM) ./Task/HAL/adc.cyclo ./Task/HAL/adc.d ./Task/HAL/adc.o ./Task/HAL/adc.su ./Task/HAL/hrtim.cyclo ./Task/HAL/hrtim.d ./Task/HAL/hrtim.o ./Task/HAL/hrtim.su

.PHONY: clean-Task-2f-HAL

