################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Task/uart_task.c \
../Task/wave_generator_task.c 

OBJS += \
./Task/uart_task.o \
./Task/wave_generator_task.o 

C_DEPS += \
./Task/uart_task.d \
./Task/wave_generator_task.d 


# Each subdirectory must supply rules for building sources it contributes
Task/%.o Task/%.su Task/%.cyclo: ../Task/%.c Task/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F334x8 -c -I../Core/Inc -I../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F3xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F3xx/Include -I../Drivers/CMSIS/Include -I../FreeRTOS/include -I../FreeRTOS/portable/GCC/ARM_CM4F -I../conf -I../Task/HAL -I"D:/Projects/PowerNetworkImitator/VoltageImitator/firmware/STM32CubeIDE/Task" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Task

clean-Task:
	-$(RM) ./Task/uart_task.cyclo ./Task/uart_task.d ./Task/uart_task.o ./Task/uart_task.su ./Task/wave_generator_task.cyclo ./Task/wave_generator_task.d ./Task/wave_generator_task.o ./Task/wave_generator_task.su

.PHONY: clean-Task

